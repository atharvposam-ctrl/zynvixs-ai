# Career UI update

Start on Windows: extract the ZIP, run Setup.bat, then Zynvixs.bat. The built frontend is included; Node.js is not required unless rebuilding it. Keep your existing data folder and models; never overwrite or delete them when updating.

This version adds a charcoal and gold career workspace and local record storage. The existing chat workspace remains accessible. Career pages currently offer basic record storage, not complete workflows. Live matching jobs, Ollama, automated interview feedback, email connections and scheduled execution are not implemented. Portal links are outbound links.

Verification: frontend production build succeeded and all 80 existing backend tests passed. Browser visual checks and complete career acceptance tests have not been performed.
